# Native Gravity Flow 501-task qualification — manual GitHub handoff

## Status and boundaries

- Source PR: `rezahh107/Gravity-Presentation-Profiles#171`
- Source Head verified before branch creation: `911447c849effc76648971a561f63bf4abbc9eca`
- Destination branch **already created**: `experiment/native-501-search-qualification`
- Intended Draft PR **base branch**: `experiment/inbox2-usability-prototype` (**not** `main`)
- Scope: only test code and CI workflow; no production code, real records, Merge, Release or deployment.
- Test file passes **Node syntax check only** in the supplied handoff; the actual WordPress/Gravity Flow/Chromium integration test has **NOT** yet been executed.

## GitHub web UI upload (two paths)

1. Select branch `experiment/native-501-search-qualification` in the GPP repository. Never upload onto `main` or PR #171's existing branch.
2. Upload `tests/qualification-custom-inbox/native-501-search-qualification.mjs`, retaining its exact path.
3. Edit the existing `.github/workflows/inbox2-usability-prototype.yml` on that **same branch**. Apply the two small edits documented below, then commit.
4. Open a **Draft PR** from `experiment/native-501-search-qualification` into **`experiment/inbox2-usability-prototype`**, not main. Confirm both head/base before submitting.
5. Observe the `Inbox 2 Usability Prototype — Isolated Runtime` workflow on that Draft PR. The added base-branch filter is required because the existing workflow only listens to PRs targeting main.
6. Capture the exact PR/Head/check-run ID. Download the uploaded workflow artifact and inspect `native-501-search-qualification.json`, `native-501-1280.png`, `native-501-390.png` and `native-501-http-metrics.ndjson` if produced. Do not interpret a generic green CI check as proof that the Native 501 discriminator ran: look for `NATIVE_501_QUALIFICATION_PASS` and matching Head.

## Edit A: enable CI on the nested experimental Draft PR

Find:

```yaml
  pull_request:
    branches:
    - main
```

Change to:

```yaml
  pull_request:
    branches:
    - main
    - experiment/inbox2-usability-prototype
```

## Edit B: run the Native test after the existing operational browser test

Find:

```yaml
        node --check tests/qualification-custom-inbox/operational-browser.mjs
        node tests/qualification-custom-inbox/operational-browser.mjs
```

Change to:

```yaml
        node --check tests/qualification-custom-inbox/operational-browser.mjs
        node tests/qualification-custom-inbox/operational-browser.mjs
        node --check tests/qualification-custom-inbox/native-501-search-qualification.mjs
        node tests/qualification-custom-inbox/native-501-search-qualification.mjs
```

`workflow-change.patch` contains precisely these two edits if using local Git (`git apply --check workflow-change.patch`, then `git apply workflow-change.patch`) **from the repository root**. It is not necessary to upload the `.patch` file to GitHub.

## Qualification mechanism and evidence

The first test (`operational-browser.mjs`) ends with exactly 501 authorized synthetic Officer tasks in disposable WU21. The new test rechecks the server oracle and Native Task Model, renames a stable synthetic old task to a unique Persian query, then loads the **actual Native Gravity Flow Inbox** at desktop and mobile widths. It tests the real Grid's `rowData` identity set, page-one visibility, typing/Enter/synthetic-keyup distinction, unique cross-page result, Entry Detail, Back, negative query, and reset. Finally it moves that task with the authentic Flow API and checks a freshly loaded 500-task Native Grid.

Status `PASS_ISOLATED_NATIVE_501` is scoped to the pinned WU21 Chromium/Gravity Flow environment and does **not** prove production performance, true mobile device experience, all IMEs, automatic Native tab refresh, or deployment readiness. If the test fails or leaves `NOT_PROVEN`, retain logs and classify whether it was fixture/setup failure, a lack of observability, or a genuine Native mismatch; never call `NOT_VERIFIED` a product defect.

## Local static validation already done

- `node --check tests/qualification-custom-inbox/native-501-search-qualification.mjs`: PASS
- Actual WordPress / Gravity Flow / Playwright CI execution: NOT RUN
- GitHub test Commit and Draft PR: NOT CREATED by the assistant
