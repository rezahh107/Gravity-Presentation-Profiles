'use strict';

( function () {

	var methodsWithBody = ['', 'post', 'put', 'patch'];

	/**
	* Dependency callback for the Request Field Values (mappings) field in the Outgoing Webhook step settings.
	*
	* @since 3.1.0
	*
	* @returns {boolean}
	*/
	window.GFlow_OutgoingWebhookMappingsCallback = function () {

		if ( ! this.args || ! this.args.prefix ) {
			return false;
		}

		var prefix   = this.args.prefix;
		var method   = document.querySelector( '[name="' + prefix + '_method"]' );
		var body     = document.querySelector( '[name="' + prefix + '_body"]:checked' );
		var bodyType = document.querySelector( '[name="' + prefix + '_body_type"]:checked' );

		if ( ! method ) {
			return false;
		}

		if ( method.value === 'get' ) {
			return true;
		}

		var isBodyMethod   = methodsWithBody.indexOf( method.value ) !== -1;
		var isSelectBody   = body && body.value === 'select';
		var isSelectFields = bodyType && bodyType.value === 'select_fields';

		if ( isBodyMethod && isSelectBody && isSelectFields ) {
			return true;
		}

		return false;
	};

} )();
